"""
URL configuration for argupedia project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from myapp import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('dashboard/<str:pk>/', views.dashboard, name='dashboard'),

    path('graph/<str:pk>', views.graph, name='graph'),
    path('sign_up/', views.sign_up, name='sign_up'),
    path('log_in/', views.log_in, name='log_in'),
    path('log_out/', views.log_out, name='log_out'),


    path('create_action/', views.create_action, name='create_action'),
    path('create_expert/', views.create_expert, name='create_expert'),
    path('create_know/', views.create_know, name='create_know'),
    path('create_analogy/', views.create_analogy, name='create_analogy'),
    path('create_correlation/', views.create_correlation, name='create_correlation'),


    path('action_scheme/', views.action_scheme, name='action_scheme'),
    path('counter_action_scheme/<str:pk>/<str:cq>', views.counter_action_scheme, name='counter_action_scheme'),
    path('counter_action/<str:pk>/<str:cq>/', views.counter_action, name='counter_action'),
    path('counter_know/<str:pk>/<str:cq>/', views.counter_know, name='counter_know'),
    path('counter_expert/<str:pk>/<str:cq>/', views.counter_expert, name='counter_expert'),
    path('counter_analogy/<str:pk>/<str:cq>/', views.counter_analogy, name='counter_analogy'),
    path('counter_correlation/<str:pk>/<str:cq>/', views.counter_correlation, name='counter_correlation'),
    
    

]
