from django.contrib import admin

from django.contrib import admin
from .models import Argument,User,CriticalQuestions

admin.site.register(Argument)
admin.site.register(User)
admin.site.register(CriticalQuestions)