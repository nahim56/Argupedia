from django.test import TestCase
from myapp.models import Argument  
from myapp.label import *

class GetCounterArgumentsTestCase(TestCase):
    """Tests labelling is applied correctly for different frameworks"""



    fixtures = ['myapp/tests/user.json']
    def setUp(self):

        self.user1 = User.objects.get(email='john_ross@mail.com')
        self.user2 = User.objects.get(email='bob_ross@mail.com')
        self.user3 = User.objects.get(email='suzy_ross@mail.com')
        self.user4 = User.objects.get(email='jane_ross@mail.com')
        self.argument1 = Argument.objects.create(user=self.user1, arg_type='')#A
        self.argument2 = Argument.objects.create(user=self.user2, arg_type='attack',parent_argument = self.argument1)#B
        self.argument3 = Argument.objects.create(user=self.user1, arg_type='attack',parent_argument = self.argument2)
        self.argument4 = Argument.objects.create(user=self.user2, arg_type='attack',parent_argument = self.argument3)



        self.argument5 = Argument.objects.create(user=self.user3, arg_type='')
        self.argument6 = Argument.objects.create(user=self.user1, arg_type='attack',parent_argument = self.argument5)
        

        

    def test_get_counter_arguments(self):
        # self.argument4 = Argument.objects.create(user=self.user2, arg_type='attack',parent_argument = self.argument3)
        all_arguments = Argument.objects.all()
        counter_arguments = get_counter_arguments(all_arguments)

        # Ensure that the correct counter arguments are returned
        self.assertIn(self.argument3, counter_arguments)
        self.assertNotIn(self.argument2, counter_arguments)
        self.assertNotIn(self.argument1, counter_arguments)
        self.assertNotIn(self.argument4, counter_arguments)# ensures no constant back and forth dialogue
        # self.assertNotIn(self.argument1, counter_arguments)
        # self.assertNotIn(self.argument2, counter_arguments)
        # self.assertNotIn(self.argument3, counter_arguments)
        # self.assertNotIn(self.argument4, counter_arguments)

    def test_scheme1(self):
        all_arguments = Argument.objects.all()
        counter_arguments = get_counter_arguments(all_arguments)
        args = grounded_algorithm_test()
        # self.argument5.save()
        # self.argument6.save()
        for arg in args:
            if arg.id == 6:
                self.assertEqual(arg.label, "IN")
            if arg.id == 5:
                self.assertEqual(arg.label, "OUT")

        
    def test_support_does_not_attack(self): #Ensures support does not act as attack
        all_arguments = Argument.objects.all()
        counter_arguments = get_counter_arguments(all_arguments)
        self.support = Argument.objects.create(user=self.user2, arg_type='support',parent_argument=self.argument6 )#L

        args = grounded_algorithm_test()
        # self.argument5.save()
        # self.argument6.save()
        for arg in args:
            if arg.id == 6:
                self.assertEqual(arg.label, "IN")
            if arg.id == 5:
                self.assertEqual(arg.label, "OUT")

    
    def test_two_way_attack(self): # ensures a two way attack leaves both arguments UNDEC
        counter = Argument.objects.create(user=self.user3, arg_type='attack',parent_argument=self.argument6 )
        all_arguments = Argument.objects.all()
        counter_arguments = get_counter_arguments(all_arguments)
        args = grounded_algorithm_test()
        for arg in args:
            if arg.id == 5:
                self.assertEqual(arg.label, "UNDEC")
            if arg.id == 6:
                self.assertEqual(arg.label, "UNDEC")



    def test_support_chain(self): # ensures an attack on supports makes them all out including the root attack
        support1 = Argument.objects.create(user=self.user2, arg_type='support',parent_argument=self.argument6 )
        support2 = Argument.objects.create(user=self.user1, arg_type='support',parent_argument=support1 )
        support3 = Argument.objects.create(user=self.user3, arg_type='support',parent_argument=support2 )
        attack4 = Argument.objects.create(user=self.user1, arg_type='attack',parent_argument=support3 )
        all_arguments = Argument.objects.all()
        counter_arguments = get_counter_arguments(all_arguments)
        args = grounded_algorithm_test()
        for arg in args:
            if arg.id == 5:
                self.assertEqual(arg.label, "IN")
            if arg.id == 6:
                self.assertEqual(arg.label, "OUT")#sup1
            if arg.id == 7:
                self.assertEqual(arg.label, "OUT")#sup1
            if arg.id == 8:
                self.assertEqual(arg.label, "OUT")#sup2
            if arg.id == 9:
                self.assertEqual(arg.label, "OUT")#sup3
            if arg.id == 10:
                self.assertEqual(arg.label, "IN")#attack4

    def test_support_check(self): # A support that does not support on the same premise cannot make anothe support in
        support1 = Argument.objects.create(user=self.user2, arg_type='support',parent_argument=self.argument6 )
        support2 = Argument.objects.create(user=self.user1, arg_type='support',parent_argument=support1 )
        support3 = Argument.objects.create(user=self.user3, arg_type='support',parent_argument=support2,critical_question = "Is action A possible?" )
        attack4 = Argument.objects.create(user=self.user1, arg_type='attack',parent_argument=support3 )
        attack5 = Argument.objects.create(user=self.user4, arg_type='support',parent_argument=support2,critical_question = "Is circumstance S true?")
        all_arguments = Argument.objects.all()
        counter_arguments = get_counter_arguments(all_arguments)
        args = grounded_algorithm_test()
        for arg in args:
            if arg.id == 5:
                self.assertEqual(arg.label, "IN")
            if arg.id == 6:
                self.assertEqual(arg.label, "OUT")#sup1
            if arg.id == 7:
                self.assertEqual(arg.label, "OUT")#sup1
            if arg.id == 8:
                self.assertEqual(arg.label, "OUT")#sup2
            if arg.id == 9:
                self.assertEqual(arg.label, "OUT")#sup3
            if arg.id == 10:
                self.assertEqual(arg.label, "IN")#attack4

    def test_support_check2(self): # A support that  support on the same premise can make anotheR support in

        support1 = Argument.objects.create(user=self.user2, arg_type='support',parent_argument=self.argument6 )
        support2 = Argument.objects.create(user=self.user1, arg_type='support',parent_argument=support1 )
        support3 = Argument.objects.create(user=self.user3, arg_type='support',parent_argument=support2,critical_question = "Is action A possible?" )
        attack4 = Argument.objects.create(user=self.user1, arg_type='attack',parent_argument=support3 )
        attack5 = Argument.objects.create(user=self.user4, arg_type='support',parent_argument=support2,critical_question = "Is action A possible?")
        all_arguments = Argument.objects.all()
        counter_arguments = get_counter_arguments(all_arguments)
        args = grounded_algorithm_test()
        for arg in args:
            if arg.id == 5:
                self.assertEqual(arg.label, "OUT") #arg6
            if arg.id == 6:
                self.assertEqual(arg.label, "IN")#sup1
            if arg.id == 7:
                self.assertEqual(arg.label, "IN")#sup1
            if arg.id == 8:
                self.assertEqual(arg.label, "IN")#sup2
            if arg.id == 9:
                self.assertEqual(arg.label, "OUT")#sup3
            if arg.id == 10:
                self.assertEqual(arg.label, "IN")#attack4


    def test_last_step_of_algorithm(self): # Ensures remaining supports are made IN 
        argument7 = Argument.objects.create(user=self.user4, arg_type='',title=1)
        support1 = Argument.objects.create(user=self.user2, arg_type='support',parent_argument=argument7 ,title=2)
        support2 = Argument.objects.create(user=self.user1, arg_type='support',parent_argument=support1,title=3 )
        support3 = Argument.objects.create(user=self.user3, arg_type='support',parent_argument=support2,title=4 )
        all_arguments = Argument.objects.all()
        counter_arguments = get_counter_arguments(all_arguments)
        args = grounded_algorithm_test()
        for arg in args:
            if arg.title == 1:
                self.assertEqual(arg.label, "IN")
            if arg.title == 2:
                self.assertEqual(arg.label, "IN")#sup1
            if arg.title == 3:
                self.assertEqual(arg.label, "IN")#sup1
            if arg.id == 4:
                self.assertEqual(arg.label, "IN")#sup3
           





        
    

