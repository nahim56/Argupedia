
from django.test import TestCase
from django.urls import reverse
from myapp.forms import LogInForm
from myapp.models import User
from myapp.tests.helpers import LogInTester



class LogInViewTestCase(TestCase,LogInTester):
    """Tests of the log in view."""

    fixtures = ['myapp/tests/user.json']

    def setUp(self):
        self.url = reverse('log_in')
        self.user = User.objects.get(email='john_ross@mail.com')
        # self.user = User.objects.create_user(
        #     first_name= "John",
        #     last_name="Ross",
        #     email="john_ross@mail.com",
        #     password="Password123",
        #     is_active = True,
        # )

    def test_log_in_url(self):
        self.assertEqual(self.url,'/log_in/')

    def test_get_log_in(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'log_in.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, LogInForm))
        self.assertFalse(form.is_bound)
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 0)




