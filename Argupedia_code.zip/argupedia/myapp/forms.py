from django import forms
from django.core.validators import RegexValidator

import datetime
from .enums import *



from myapp.models import User,Argument



class LogInForm(forms.Form):
    email = forms.EmailField(label='Email')
    password = forms.CharField(label='Password', widget=forms.PasswordInput())


class SignUpForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email']

    password = forms.CharField(label='Password', widget=forms.PasswordInput(), validators=[
        RegexValidator(regex=r'^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).*$',
                       message='Password must contain an uppercase character, a lowercase '
                               'character and a number')])
    confirm_password = forms.CharField(label='Re-enter Password', widget=forms.PasswordInput())

    def clean(self):
        super().clean()
        password = self.cleaned_data.get('password')
        confirm_password = self.cleaned_data.get('confirm_password')
        if confirm_password != password:
            self.add_error('confirm_password', 'Passwords do not match')

    def save(self):
        super().save(commit=False)
        user = User(username = self.cleaned_data.get('username'),
                    email=self.cleaned_data.get('email'),)
        user.set_password(self.cleaned_data.get('password'))
        user.save()
        return user
    

# class ArgumentForm(forms.ModelForm):
#     class Meta:
#         model = Argument
#         fields = ['scheme', 'S', 'A', 'G', 'R', 'V', 'E', 'P', 'D', 'title', 'description']

#     def __init__(self, *args, **kwargs):
#         super(ArgumentForm, self).__init__(*args, **kwargs)
#         # Set initial visibility of fields based on the scheme
#         self.fields['S'].widget.attrs['style'] = 'display:none;'
#         self.fields['A'].widget.attrs['style'] = 'display:none;'
#         self.fields['G'].widget.attrs['style'] = 'display:none;'
#         self.fields['R'].widget.attrs['style'] = 'display:none;'
#         self.fields['V'].widget.attrs['style'] = 'display:none;'
#         self.fields['E'].widget.attrs['style'] = 'display:none;'
#         self.fields['P'].widget.attrs['style'] = 'display:none;'
#         self.fields['D'].widget.attrs['style'] = 'display:none;'

#         # You'll need JavaScript to dynamically show/hide fields based on scheme selection
#         self.fields['scheme'].widget.attrs['onchange'] = 'showHideFields(this.value);'

class ActionForm(forms.ModelForm):
    class Meta:
        model = Argument
        fields = ['title','S', 'A', 'G', 'R', 'V','topic','arg_type']

    S = forms.CharField(label='In circumstance S')
    A = forms.CharField(label='do action A')
    G = forms.CharField(label='to achieve goal S')
    R = forms.CharField(label='effect R')
    V = forms.CharField(label='value V')
    arg_type = forms.CharField(label='Are you supporting or attacking?', widget=forms.Select(choices=ARG_TYPE),initial='attack',required = False)

    def __init__(self, *args, **kwargs):
        super(ActionForm, self).__init__(*args, **kwargs)

class PositionToKnowForm(forms.ModelForm):
    class Meta:
        model = Argument
        fields = ['title','person', 'assertion', 'conclusion','topic','arg_type']

    
    topic = forms.CharField(label='Topic(Optional)', widget=forms.Select(choices=TOPICS),required = False)
    person = forms.CharField(label='Person a(Name the person and their relation to assertion)')
    assertion = forms.CharField(label='Assertion A')
    conclusion = forms.CharField(label='Conclusion C')
    arg_type = forms.CharField(label='Are you supporing or attacking?', widget=forms.Select(choices=ARG_TYPE),initial='attack',required = False)

    def __init__(self, *args, **kwargs):
        super(PositionToKnowForm, self).__init__(*args, **kwargs)


class ArgumentFromAnalogyForm(forms.ModelForm):
    class Meta:
        model = Argument
        fields = ['title','case_1', 'case_2','base_premise', 'conclusion','topic','arg_type']

    topic = forms.CharField(label='Topic(Optional)', widget=forms.Select(choices=TOPICS),required = False)
    case_1 = forms.CharField(label='Case C1')
    case_2 = forms.CharField(label='Case C2')
    base_premise = forms.CharField(label='Premise A')
    conclusion = forms.CharField(label='Conclusion C')
    arg_type = forms.CharField(label='Are you supporting or attacking?', widget=forms.Select(choices=ARG_TYPE),initial='attack',required = False)

    def __init__(self, *args, **kwargs):
        super(ArgumentFromAnalogyForm, self).__init__(*args, **kwargs)


class CorrelationToCauseForm(forms.ModelForm):
    class Meta:
        model = Argument
        fields = ['title','case_1', 'case_2','topic','arg_type','conclusion']
     
    topic = forms.CharField(label='Topic(Optional)', widget=forms.Select(choices=TOPICS),required = False)
    case_1 = forms.CharField(label='Event A')
    case_2 = forms.CharField(label='Event B')
    conclusion = forms.CharField(label='Conclusion C')
    arg_type = forms.CharField(label='Are you supporting or attacking?', widget=forms.Select(choices=ARG_TYPE),initial='attack',required = False)

    def __init__(self, *args, **kwargs):
        super(CorrelationToCauseForm, self).__init__(*args, **kwargs)




class ExpertForm(forms.ModelForm):
    class Meta:
        model = Argument
        fields = ['title','E', 'P', 'D','topic','arg_type']
    
    topic = forms.CharField(label='Topic(Optional)', widget=forms.Select(choices=TOPICS),required = False)
    E = forms.CharField(label='Expert E(Name the expert and their relation to assertion)')
    P = forms.CharField(label='Assertion P')
    D = forms.CharField(label='Conclusion D')
    arg_type = forms.CharField(label='Are you supporting or attacking?', widget=forms.Select(choices=ARG_TYPE),initial='attack',required = False)

    def __init__(self, *args, **kwargs):
        super(ExpertForm, self).__init__(*args, **kwargs)
