from django.shortcuts import render,HttpResponse
from datetime import datetime, timedelta

from django.shortcuts import render
from .forms import SignUpForm, LogInForm,ActionForm,ExpertForm,PositionToKnowForm,ArgumentFromAnalogyForm,CorrelationToCauseForm
from django.contrib.auth import login, authenticate, logout
from django.shortcuts import redirect
from django.contrib import messages
from .models import User,Argument,CriticalQuestions
from django.contrib.auth.decorators import login_required
# from .helpers import login_prohibited
from django.views.generic.list import ListView
from django.template.loader import render_to_string
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse, JsonResponse
from .label import grounded_algorithm,get_arguments,get_counter_arguments
import json
from django.core.serializers.json import DjangoJSONEncoder

from django import forms

def log_in(request):
    if request.method == "POST":
        form = LogInForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = authenticate(request, email=email, password=password)
            if user is None:
                messages.error(request, "Invalid credentials.")
                form = LogInForm()
                return render(request, 'log_in.html', {'form': form})
            if user is not None:
                login(request, user)
                return redirect('home')

    form = LogInForm()
    return render(request, 'log_in.html', {'form': form})


def sign_up(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = SignUpForm()
    return render(request, 'sign_up.html', {'form': form})



def graph(request, pk):                 #method for converting arguments to JSON taken from https://stackoverflow.com/questions/38654599/django-best-way-to-pass-data-to-javascript
    arg = Argument.objects.get(id=pk)
    arguments = get_arguments(arg)
    counter_arguments = get_counter_arguments(arguments)
    arguments_data = []
    for argument in arguments:
        source = argument.id
        target = argument.parent_argument.id if argument.parent_argument else ''
        counter_ids = [counter.id for counter in argument.counter_argument.all()]

        if argument in counter_arguments:
            source = argument.parent_argument.parent_argument.id
            target = argument.parent_argument.id

        if argument.parent_argument in counter_arguments:
            # if argument.parent_argument.parent_argument.parent_argument.user == argument.parent_argument.user:
            source = argument.id
            target = argument.parent_argument.parent_argument.parent_argument.id

        argument_dict = {
            'id': argument.id,
            'counter_id':counter_ids,
            'type': argument.type,
            'author': argument.user.username,
            'cq': argument.critical_question,
            'title': argument.title,
            'parent': argument.parent_argument.title if argument.parent_argument else None,
            'source': source,
            'arg_type': argument.arg_type,
            'scheme': argument.type,

            'circumstance': argument.S if argument.S else '',
            'action': argument.A if argument.A else '',
            'goal': argument.G if argument.G else '',
            'result': argument.R if argument.R else '',
            'value': argument.V if argument.V else '',

            'expert':argument.E if argument.E else '',
            'claim':argument.P if argument.P else '',
            'domain': argument.D if argument.D  else '',

            'person':argument.person if argument.person else '',
            'assertion': argument.assertion if argument.assertion else '',
            'conclusion':argument.conclusion if argument.conclusion else '',

            'case_1':argument.case_1 if argument.case_1 else '',
            'case_2': argument.case_2 if argument.case_2 else '',
            'base_premise': argument.base_premise if argument.base_premise else '',

            'target': target,
            'label': argument.label,
        }

        arguments_data.append(argument_dict)

    context = {'arguments': json.dumps(arguments_data)}
    return render(request, 'graph.html', context)




def log_out(request):
    logout(request)
    return redirect('home')

def home(request):
    
    arguments = Argument.objects.all()
    counter_args = get_counter_arguments(arguments)
    topic = request.GET.get('topic')
    if not topic:
        grounded_algorithm()
    if topic:
        arguments = Argument.objects.filter(parent_argument_id=None, topic=topic)
    else:
        arguments = Argument.objects.filter(parent_argument_id=None)
    for arg in arguments:
        arg.children = Argument.objects.filter(parent_argument=arg)
    # arguments = Argument.objects.all().filter(parent_argument_id=None)
    context = {'arguments': arguments,'counter_args':counter_args}

    
    return render(request, 'home.html', context)



def action_scheme(request):
    return render(request, 'action_scheme.html')

def counter_action_scheme(request,pk,cq):
    arg = Argument.objects.all().get(id=pk)
    cq = CriticalQuestions.objects.all().get(id=cq)
    context = {'arg':arg,'cq':cq}
    return render(request, 'counter_action_scheme.html',context)

def dashboard(request,pk):
    arg = Argument.objects.all().get(id=pk)
    critical_questions = CriticalQuestions.objects.all().filter(type=arg.type)
    counter_arguments = Argument.objects.all().filter(parent_argument_id=pk)
    context = {'arg':arg,'counter_arguments':counter_arguments,'critical_questions':critical_questions}
    return render(request, 'dashboard.html',context)


def create_action(request):
    if request.method == 'POST':
        form = ActionForm(request.POST)
        if form.is_valid():
            argument = form.save(commit=False)
            argument.user = request.user  
            argument.type = "action"
            argument.save()
            messages.success(request, "Argument Created!")
            return redirect('home')
        else:
            messages.error(request, "Invalid form input")
    else:
        form = ActionForm()

    if 'arg_type' in form.fields:
        del form.fields['arg_type']
    return render(request, 'create_action.html', {'form': form})


def create_know(request):
    if request.method == 'POST':
        form = PositionToKnowForm(request.POST)
        if form.is_valid():
            argument = form.save(commit=False)
            argument.user = request.user  
            argument.type = "position_to_know"
            argument.save()
            messages.success(request, "Argument Created!")
            return redirect('home')
        else:
            messages.error(request, "Invalid form input")
    else:
        form = PositionToKnowForm()

    if 'arg_type' in form.fields:
        del form.fields['arg_type']
    return render(request, 'create_know.html', {'form': form})

def create_expert(request):
    if request.method == 'POST':
        form = ExpertForm(request.POST)
        if form.is_valid():
            argument = form.save(commit=False)
            argument.user = request.user  

            argument.type = "expert"
            argument.save()
            messages.success(request, "Argument Created!")
            return redirect('home')
        else:
            messages.error(request, "Invalid form input")
    else:
        form = ExpertForm()

    if 'arg_type' in form.fields:
        del form.fields['arg_type']

    
    return render(request, 'create_expert.html', {'form': form})


def create_analogy(request):
    if request.method == 'POST':
        form = ArgumentFromAnalogyForm(request.POST)
        if form.is_valid():
            argument = form.save(commit=False)
            argument.user = request.user  # Assign the user to the argument

            argument.type = "argument_from_analogy"
            argument.save()
            messages.success(request, "Argument Created!")
            return redirect('home')
        else:
            messages.error(request, "Invalid form input")
    else:
        form = ArgumentFromAnalogyForm()

    if 'arg_type' in form.fields:
        del form.fields['arg_type']
    
    return render(request, 'create_analogy.html', {'form': form})

def create_correlation(request):
    if request.method == 'POST':
        form = CorrelationToCauseForm(request.POST)
        if form.is_valid():
            argument = form.save(commit=False)
            argument.user = request.user 
            argument.type = "correlation_to_cause"
            argument.save()
            messages.success(request, "Argument Created!")
            return redirect('home')
        else:
            messages.error(request, "Invalid form input")
    else:
        form = CorrelationToCauseForm()

    if 'arg_type' in form.fields:
        del form.fields['arg_type']

    
    return render(request, 'create_correlation.html', {'form': form})


def counter_action(request,pk,cq):
    arg = Argument.objects.all().get(id=pk)
    cq = CriticalQuestions.objects.all().get(id=cq)
    user = request.user
    if request.method == 'POST':
        form = ActionForm(request.POST)
        if form.is_valid():
            argument = form.save(commit=False)
            argument.user = request.user  
            arg = Argument.objects.all().get(id=pk)
            if argument.arg_type=="attack":
                arg.count_attackers +=1
                arg.save()
            argument.parent_argument = arg
            argument.type = "action"
            argument.critical_question = cq.question
            argument.save()
            grounded_algorithm()
            messages.success(request, "Argument Created!")
            return redirect('home')
        else:
            messages.error(request, "Invalid form input")
    else:
        form = ActionForm()
    if user==arg.user:
        form.fields['arg_type'] = forms.ChoiceField(choices=[('support', 'support')])
    
    return render(request, 'counter_action.html', {'form': form,'arg':arg,'cq':cq})

def counter_expert(request,pk,cq):

    arg = Argument.objects.all().get(id=pk)
    cq = CriticalQuestions.objects.all().get(id=cq)
    user = request.user
    if request.method == 'POST':
        form = ExpertForm(request.POST)
        if form.is_valid():
            argument = form.save(commit=False)
            argument.user = request.user  # Assign the user to the argument
            argument.type = "expert"
            arg = Argument.objects.all().get(id=pk)
            if argument.arg_type=="attack":
                arg.count_attackers +=1
                arg.save()
            argument.parent_argument = arg
            argument.critical_question = cq.question
            argument.save()
            grounded_algorithm()
            messages.success(request, "Argument Created!")
            return redirect('home')
        else:
            messages.error(request, "Invalid form input")
    else:
        form = ExpertForm()

    if user==arg.user:
        form.fields['arg_type'] = forms.ChoiceField(choices=[('support', 'support')])
    return render(request, 'counter_expert.html', {'form': form,'arg':arg,'cq':cq})

def counter_know(request,pk,cq):
    arg = Argument.objects.all().get(id=pk)
    cq = CriticalQuestions.objects.all().get(id=cq)
    user = request.user
    if request.method == 'POST':
        form = PositionToKnowForm(request.POST)
        if form.is_valid():
            argument = form.save(commit=False)
            argument.user = request.user  # Assign the user to the argument
            argument.type = "position_to_know"
            arg = Argument.objects.all().get(id=pk)

            if argument.arg_type=="attack":
                arg.count_attackers +=1
                arg.save()
            argument.parent_argument = arg
            argument.critical_question = cq.question
            argument.save()
            grounded_algorithm()
            messages.success(request, "Argument Created!")
            return redirect('home')
        else:
            messages.error(request, "Invalid form input")
    else:
        form = PositionToKnowForm()
    
    if user==arg.user:
        form.fields['arg_type'] = forms.ChoiceField(choices=[('support', 'support')])
    return render(request, 'schemes/counter_know.html', {'form': form,'arg':arg,'cq':cq})


def counter_analogy(request,pk,cq):
    arg = Argument.objects.all().get(id=pk)
    cq = CriticalQuestions.objects.all().get(id=cq)
    user = request.user
    if request.method == 'POST':
        form = ArgumentFromAnalogyForm(request.POST)
        if form.is_valid():
            argument = form.save(commit=False)
            argument.user = request.user 
            argument.type = "argument_from_analogy"
            arg = Argument.objects.all().get(id=pk)

            if argument.arg_type=="attack":
                arg.count_attackers +=1
                arg.save()
            argument.parent_argument = arg
            argument.critical_question = cq.question
            argument.save()
            grounded_algorithm()
            messages.success(request, "Argument Created!")
            return redirect('home')
        else:
            messages.error(request, "Invalid form input")
    else:
        form = ArgumentFromAnalogyForm()

    if user==arg.user:
        form.fields['arg_type'] = forms.ChoiceField(choices=[('support', 'support')])
    return render(request, 'counter_analogy.html', {'form': form,'arg':arg,'cq':cq})


def counter_correlation(request,pk,cq):
    arg = Argument.objects.all().get(id=pk)
    cq = CriticalQuestions.objects.all().get(id=cq)
    user = request.user
    if request.method == 'POST':
        form = CorrelationToCauseForm(request.POST)
        if form.is_valid():
            argument = form.save(commit=False)
            argument.user = request.user 
            argument.type = "correlation_to_cause"
            arg = Argument.objects.all().get(id=pk)

            if argument.arg_type=="attack":
                arg.count_attackers +=1
                arg.save()
            argument.parent_argument = arg
            argument.critical_question = cq.question
            argument.save()
            grounded_algorithm()
            messages.success(request, "Argument Created!")
            return redirect('home')
        else:
            messages.error(request, "Invalid form input")
    else:
        form =CorrelationToCauseForm()
    
    if user==arg.user:
        form.fields['arg_type'] = forms.ChoiceField(choices=[('support', 'support')])
    return render(request, 'counter_correlation.html', {'form': form,'arg':arg,'cq':cq})

