TOPICS = [
    ('SPORTS', 'SPORTS'),
    ('POLITICS', 'POLITICS'),
    ('MOVIES', 'MOVIES'),
    ('HEALTH', 'HEALTH'),
    ('GAMES', 'GAMES'),
    ("", "----"),
]

ARG_TYPE = [
    ('attack', 'attack'),
    ('support', 'support'),
]
