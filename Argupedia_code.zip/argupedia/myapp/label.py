from .models import User,Argument,CriticalQuestions
from django.utils import timezone
from collections import deque
import copy
from collections import Counter





def grounded_algorithm():
    """Execute step 1 of grounded algorithm"""
    all_arguments = Argument.objects.all()

    in_count = Argument.objects.filter(label = "IN")
    out_count = Argument.objects.filter(label = "OUT")

    for arg in all_arguments:
         arg.label = "UNDEC"
         arg.count_attackers_out = 0
         arg.save()
         if is_not_attacked_and_not_supported(arg) :
              arg.label="IN"
              arg.save()
    grounded(in_count.count(),out_count.count(),all_arguments)
    return

def grounded_algorithm_test():
    """Function only used for testing"""
    all_arguments = Argument.objects.all()

    in_count = Argument.objects.filter(label = "IN")
    out_count = Argument.objects.filter(label = "OUT")

    for arg in all_arguments:
         arg.label = "UNDEC"
         arg.count_attackers_out = 0
         arg.save()
         if is_not_attacked_and_not_supported(arg) :
              arg.label="IN"
              arg.save()
    grounded(in_count.count(),out_count.count(),all_arguments)
    args = Argument.objects.all()
    return args


def is_not_attacked_and_not_supported(arg):
    """
    Check if an argument is not supported and not attacked. return True if not supported and not attacked
    """
    children = Argument.objects.filter(parent_argument=arg)
    for child in children:
        if child.arg_type == "attack" or child.arg_type=="support":
            return False  
    return True 


def is_not_attacked(arg):
    """
    Check if an argument is attacked. Return False if attacked.
    """
    children = Argument.objects.filter(parent_argument=arg)
    for child in children:
        if child.arg_type == "attack":
            return False  
    return True 

def is_supported(arg):
    """
    Check if an argument is supported. Return True if supported.
    """
    children = Argument.objects.filter(parent_argument=arg)
    for child_arg in children:
        if child_arg.arg_type == "support":
            return True  
    return False 


def find_root_argument(arg,counter):
    """
    Find  the root argument of a support chain. The root is the first non-support argument encountered
    """
    current_argument = arg
    if current_argument.parent_argument in counter:
         return current_argument.parent_argument.parent_argument.parent_argument  # If the argument is a counter- attack, skip over it.  
    if current_argument.parent_argument.arg_type == "" :
         return current_argument.parent_argument
    if current_argument.parent_argument.arg_type == "attack" :
         return current_argument.parent_argument

    while current_argument.parent_argument and current_argument.parent_argument.arg_type == "support":
        current_argument = current_argument.parent_argument
    if current_argument.parent_argument in counter:
         return current_argument.parent_argument.parent_argument.parent_argument 

    return current_argument.parent_argument


def find_root_attack_from_in(arg):
    """
    given an IN attack argument, traverse  to the next attack argument while making all supports in the way OUT. If support passes support check, then make it IN instead. Return the argument before the root
    """
    current_argument = arg
    if not current_argument.parent_argument:
         return
    if current_argument.parent_argument.arg_type == "" :
         return current_argument
    if current_argument.parent_argument.arg_type == "attack" :
         return current_argument
    while current_argument.parent_argument and current_argument.parent_argument.arg_type == "support":
        prev_argument = current_argument
        current_argument = current_argument.parent_argument
        if is_not_attacked(current_argument) and is_supported(current_argument):
           child_arguments = Argument.objects.filter(parent_argument=current_argument)
           for child in child_arguments:
                if child.arg_type=="support" and child.label == "IN" and child.critical_question==prev_argument.critical_question:
                    current_argument.label = "IN"
                    current_argument.save()
                    break
           else:
               current_argument.label = "OUT"
               current_argument.save()
        else:
          current_argument.label = "OUT"
          current_argument.save()
    return current_argument

def find_root_attack_from_out(arg):
    """
    given an OUT attack argument, traverse  to the next attack argument while making all supports in the way IN.
    """
    current_argument = arg
    if not current_argument.parent_argument:
         return
    if current_argument.parent_argument.arg_type == "" :
         return current_argument.parent_argument
    if current_argument.parent_argument.arg_type == "attack" :
         return current_argument.parent_argument

    while current_argument.parent_argument and current_argument.parent_argument.arg_type == "support":
        current_argument = current_argument.parent_argument
        current_argument.label = "IN"
        current_argument.save()
    return current_argument.parent_argument




def set_attackers(counter):
    """Finds all indirect and direct attackers of an argument"""
    attackers = Counter()
    all_arguments = Argument.objects.all().exclude(arg_type="support")
    for arg in all_arguments:
        if arg.parent_argument:
            root_argument = find_root_argument(arg,counter)
            attackers[root_argument.id] += 1
    return attackers

def grounded(in_count,out_count,args):
     """Performs the rest of the grounded algorithm """
     all_arguments = args.exclude(arg_type="support")
     counter_arguments = get_counter_arguments(args) # These find arguments that are a counter attack from an argument attacking it.
     attackers = set_attackers(counter_arguments)
     # print("attackers",attackers)
     for arg in all_arguments:
          if arg in counter_arguments: #Skip over arguments that are counter-arguments
            continue
          if arg.label=="IN" and arg.parent_argument:
                    pre_argument = find_root_attack_from_in(arg)#This finds the argument before  the next attack argument from the current attack argument. go over all the supports and make them OUT 

                    root_argument = pre_argument.parent_argument # find the next attack argument from the current attack argument. 
                    if root_argument in counter_arguments:
                         root_argument = root_argument.parent_argument.parent_argument # If the argument is a counter- attack, skip over it.
                    if root_argument.label != "OUT":
                         if pre_argument.label == "IN" and pre_argument.arg_type == "support": 
                              root_argument.label = "IN"
                              root_argument.save()
                         else:
                              new_root = find_root_attack_from_out(root_argument)
                               # find the next attack argument from the current OUT attack argument. go over all the supports and make them IN
                              if new_root:
                                   if new_root in counter_arguments:
                                     print("NEW ROOT FOUND",new_root.title,new_root.parent_argument.parent_argument.title )
                                     new_root = new_root.parent_argument.parent_argument

                                   new_root.count_attackers_out +=1      
                                   new_root.save()

                              for counter_arg in root_argument.counter_argument.all():
                                   if counter_arg:
                                        if new_root and counter_arg == new_root:
                                             print(".")
                                        else:
                                             print("..",root_argument.title, counter_arg.id)
                                             counter_arg.parent_argument.count_attackers_out += 1
                                             counter_arg.parent_argument.save()

                              root_argument.label = "OUT"  
                              root_argument.save()

     for arg in all_arguments:
          if attackers[arg.id] == arg.count_attackers_out:
               arg.label = "IN"
               arg.save()
     in_cnt = Argument.objects.filter(label = "IN")
     out_cnt = Argument.objects.filter(label = "OUT")
     if in_cnt.count()==in_count and out_count==out_cnt.count():
          sup_arguments = Argument.objects.all().exclude(arg_type="attack").exclude(arg_type = "")
          for sup in sup_arguments:
               if sup.arg_type == "support" and sup.label == "UNDEC":
                    print(sup.title)
                    sup.label = "IN"
                    sup.save()
          for current_argument in all_arguments:
               if is_not_attacked(current_argument) and is_supported(current_argument):
                    child_arguments = Argument.objects.filter(parent_argument=current_argument)
                    for child in child_arguments:
                         if child.arg_type=="support" and child.label == "OUT":
                              for next_child in child_arguments:
                                   if next_child!=child and next_child.critical_question==child.critical_question and next_child.label == "IN":
                                        current_argument.label = "IN"
                                        current_argument.save()
                                        break
                              else:
                                   current_argument.label = "OUT"
                                   current_argument.save()
               
          return
     else:
          grounded(in_cnt.count(),out_cnt.count(),all_arguments)


def get_counter_arguments(all_arguments): 
     """This function returns any arguments that are counter arguments which should not be visualised in the graph."""
     arg_counter = []
     for argument in all_arguments:
          if (argument.parent_argument and argument.parent_argument.parent_argument and argument.parent_argument.parent_argument.user == argument.user and
               argument.arg_type == 'attack' and argument.parent_argument.user != argument.user and argument.parent_argument.arg_type == 'attack' and 
               (not argument.parent_argument.parent_argument.parent_argument or argument.parent_argument.parent_argument.parent_argument.user != argument.parent_argument.user)):
                    counter_arguments = argument.parent_argument.parent_argument.counter_argument.all()
                    counter_arguments = list(counter_arguments)
                    counter_arguments.append(argument)
                    argument.parent_argument.parent_argument.counter_argument.set(counter_arguments)
                    # argument.parent_argument.parent_argument.counter_argument = argument
                    argument.parent_argument.parent_argument.save()
                    arg_counter.append(argument)
     return arg_counter



def get_arguments(root):
        """All arguments of a parent retrieved using a standard breadth first search. https://github.com/neetcode-gh/leetcode/blob/main/python/0102-binary-tree-level-order-traversal.py """
        
        q = deque()
        arguments = []

        if root:
            q.append(root)

        while q:
            cur = q.popleft()
            arguments.append(cur)
            children = Argument.objects.filter(parent_argument=cur)
            q.extend(children)

        return arguments