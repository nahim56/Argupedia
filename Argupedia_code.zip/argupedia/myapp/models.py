from django.core.exceptions import ValidationError
from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.core.validators import MinValueValidator
from django.contrib.auth.models import Group, Permission
from .enums import *
from polymorphic.models import PolymorphicModel

from django.utils import timezone

class UserManager(BaseUserManager):
    def create_user(self, email, password, **kwargs):
        if not email:
            raise ValueError('user needs email')
        user_email = self.normalize_email(email)
        user = self.model(email=user_email, **kwargs)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password, **kwargs):
        kwargs.setdefault('is_staff', True)
        kwargs.setdefault('is_superuser', True)
        kwargs.setdefault('username','admin')
        
        return self.create_user(email, password, **kwargs)


class User(AbstractUser):
    username = models.CharField(max_length=30, blank=False, null=False)
    email = models.EmailField(unique=True, max_length=50)
    USERNAME_FIELD = 'email'
    
    REQUIRED_FIELDS = []
    objects = UserManager()

 

    def save(self, *args, **kwargs):
        self.full_clean()
        return super().save(*args, **kwargs)

    def __str__(self):
        return str(self.id)
    
class CriticalQuestions(models.Model):
    question =  models.CharField(max_length=100, blank=True, null=True)
    type = models.CharField(max_length=100, blank=True, null=True)

    
class Argument(models.Model):
    # Fields for all schemes
    label = models.CharField(max_length=100, blank=True, null=True,default = "UNDEC")
    parent_argument = models.ForeignKey('self',null=True,blank=True,on_delete=models.CASCADE,related_name = 'parent')
    count_attackers = models.PositiveIntegerField(default=0)
    count_attackers_out = models.PositiveIntegerField(default=0) 
    critical_question = models.CharField(max_length=100, blank=True, null=True)
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        blank=False,
    )
    posted = models.DateTimeField(auto_now_add = True)
    arg_type= models.CharField(max_length=30, choices=ARG_TYPE, blank=True, null=True)
    type = models.CharField(max_length=100, blank=True, null=True)
    title = models.CharField(max_length=1000, blank=True, null=True)
    topic = models.CharField(max_length=30, choices=TOPICS, blank=True, null=True)

    # is_counter_attack = models.BooleanField(default=False)
    

    counter_argument = models.ManyToManyField(
        'self',
        null=True,
        blank=True,
        related_name='counter_args'
    )
    # Additional scheme fields

    # ACTION SCHEME
    S = models.CharField(max_length=1000, blank=True, null=True) # Circumstance
    A = models.CharField(max_length=1000, blank=True, null=True) # Action
    G = models.CharField(max_length=1000, blank=True, null=True)# Goal
    R = models.CharField(max_length=1000, blank=True, null=True)# Result
    V = models.CharField(max_length=1000, blank=True, null=True)# Value

    #EXPERT SCHEME
    E = models.CharField(max_length=1000, blank=True, null=True) #Expert
    P = models.CharField(max_length=1000, blank=True, null=True) #Assertion
    D = models.CharField(max_length=1000, blank=True, null=True) # Conclusion


    #POSITION TO KNOW SCHEME
    person = models.CharField(max_length=1000, blank=True, null=True) #Person in position to know
    # Relation = models.CharField(max_length=100, blank=True, null=True) #
    assertion = models.CharField(max_length=1000, blank=True, null=True) #Assertion 
    conclusion = models.CharField(max_length=1000, blank=True, null=True) # Conclusion  
    #Person and is therefore in position to know whether 'ASSERTION' is true or false because Relation. Person asserts that A is true/false. therefore Conclusion


    #ARGUMENT FROM ANALOGY SCHEME AND CORRELATION SCHEME

    case_1 =  models.CharField(max_length=1000, blank=True, null=True)
    case_2 = models.CharField(max_length=1000, blank=True, null=True)
    base_premise = models.CharField(max_length=1000, blank=True, null=True)
    # conclusion = models.CharField(max_length=100, blank=True, null=True)



    

    class Meta:
        ordering = ['posted']
    

    def __str__(self):
        return str(self.id)
    
    def delete(self, *args, is_admin=True, is_expired=False, **kwargs):
        """
        """
        super().delete(*args, **kwargs)


# class ActionArgument(Argument):
#     S = models.CharField(max_length=100, blank=True, null=True)
#     A = models.CharField(max_length=100, blank=True, null=True)
#     G = models.CharField(max_length=100, blank=True, null=True)
#     R = models.CharField(max_length=100, blank=True, null=True)
#     V = models.CharField(max_length=100, blank=True, null=True)

            